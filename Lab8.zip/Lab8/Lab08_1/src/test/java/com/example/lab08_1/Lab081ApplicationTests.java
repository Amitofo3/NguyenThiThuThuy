package com.example.lab08_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab081ApplicationTests {

    @Test
    void contextLoads() {
    }

}
