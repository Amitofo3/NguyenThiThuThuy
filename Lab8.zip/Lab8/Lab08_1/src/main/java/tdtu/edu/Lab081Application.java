package tdtu.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab081Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab081Application.class, args);
    }

}
