package vn.edu.tdtu.Lab7_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab71ApplicationTests {

	@Test
	void contextLoads() {
	}

}
