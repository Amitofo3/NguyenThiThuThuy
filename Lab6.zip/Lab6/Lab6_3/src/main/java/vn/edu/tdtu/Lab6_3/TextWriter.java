package vn.edu.tdtu.Lab6_3;

import java.io.IOException;

public interface TextWriter {
    public void write(String fileName, String text) throws IOException;
}
