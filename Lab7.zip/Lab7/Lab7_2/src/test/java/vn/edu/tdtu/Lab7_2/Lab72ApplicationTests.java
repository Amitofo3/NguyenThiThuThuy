package vn.edu.tdtu.Lab7_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab72ApplicationTests {

	@Test
	void contextLoads() {
	}

}
