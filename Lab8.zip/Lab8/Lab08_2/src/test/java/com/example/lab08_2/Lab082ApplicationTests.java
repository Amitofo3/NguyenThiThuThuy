package com.example.lab08_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab082ApplicationTests {

    @Test
    void contextLoads() {
    }

}
