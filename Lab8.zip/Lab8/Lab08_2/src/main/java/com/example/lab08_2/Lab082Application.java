package com.example.lab08_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab082Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab082Application.class, args);
    }

}
