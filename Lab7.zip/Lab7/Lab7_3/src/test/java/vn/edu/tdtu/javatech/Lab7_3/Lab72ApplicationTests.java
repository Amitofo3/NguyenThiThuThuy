package vn.edu.tdtu.javatech.Lab7_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab72ApplicationTests {

	@Test
	void contextLoads() {
	}

}
